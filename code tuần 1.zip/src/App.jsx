import { Home } from "./pages/Home";
import Image from "./components/Image";
import CourseDetail from "./pages/CourseDetail";
const App = () => {
  return (
    <div>
      {/* <Home /> */}
      <CourseDetail />
    </div>
  );
};

export default App;
